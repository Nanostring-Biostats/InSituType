library(testthat)
library(InSituType)
test_check("InSituType")
