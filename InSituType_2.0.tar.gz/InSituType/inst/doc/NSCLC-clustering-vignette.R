## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----installation, eval=FALSE-------------------------------------------------
#  
#  # TBD
#  

## ----setup--------------------------------------------------------------------
library(InSituType)
data("ioprofiles")
data("iocolors")
data("mini_nsclc")
str(mini_nsclc)
set.seed(0)

## ----strcounts----------------------------------------------------------------
counts <- mini_nsclc$counts
str(counts)
counts[25:30, 9:14]


## ----strnegmean---------------------------------------------------------------
negmean <- Matrix::rowMeans(mini_nsclc$neg)
head(negmean)

## ----cohorting, echo = TRUE---------------------------------------------------
# simulate immunofluorescence data: 
immunofluordata <- matrix(rpois(n = nrow(counts) * 4, lambda = 100), 
                          nrow(counts))
# perform automatic cohorting:
cohort <- fastCohorting(immunofluordata,
                        gaussian_transform = TRUE) 
# ("Gaussian_transform = TRUE" maps variables to gaussians in order to 
#  place dramatically different variables on the same scale.)
table(cohort)

## ----unsup, echo=TRUE---------------------------------------------------------
unsup <- insitutype(
  x = counts,
  neg = negmean,
  cohort = cohort,
  # Enter your own per-cell background estimates here if you have them;
  # otherwise insitutype will use the negprobes to estimate background for you.
  bg = NULL,
  # condensed to save time. n_clusts = 5:20 would be more optimal
  n_clusts = c(10, 12),
  # NULL value runs unsupervised clustering; entering a matrix here would run
  # semi-supervised clustering.
  reference_profiles = NULL,
  n_phase1 = 200,
  n_phase2 = 500,
  n_phase3 = 2000,
  n_starts = 1,
  max_iters = 5
) # choosing inadvisably low numbers to speed the vignette; using the defaults in recommended.

## ----unsup_results, fig.width = 8, fig.height = 5-----------------------------
str(unsup)
round(head(unsup$prob), 2)
heatmap(sweep(unsup$profiles, 1, pmax(apply(unsup$profiles, 1, max), .2), "/"), scale = "none",
        main = "Cluster mean expression profiles")

# define cluster colors:
cols <-
  c(
    '#8DD3C7',
    '#BEBADA',
    '#FB8072',
    '#80B1D3',
    '#FDB462',
    '#B3DE69',
    '#FCCDE5',
    '#D9D9D9',
    '#BC80BD',
    '#CCEBC5',
    '#FFED6F',
    '#E41A1C',
    '#377EB8',
    '#4DAF4A',
    '#984EA3',
    '#FF7F00',
    '#FFFF33',
    '#A65628',
    '#F781BF',
    '#999999'
  )
cols <- cols[seq_along(unique(unsup$clust))]
names(cols) <- unique(unsup$clust)

par(mfrow = c(1, 2))
par(mar = c(0, 0, 3, 0))

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "cells in physical space",
     col = cols[unsup$clust], xlab = "", ylab = "", xaxt = "n", yaxt = "n")

plot(mini_nsclc$umap, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
     main = "cells in UMAP space",     
     col = cols[unsup$clust], xlab = "", ylab = "", xaxt = "n", yaxt = "n")
legend("bottomleft", pch = 16, col = cols, legend = names(cols), cex = 0.7)



## ----flightpath, fig.width = 5, fig.height = 5--------------------------------
# define colors:
cols <-
  c(
    '#8DD3C7',
    '#BEBADA',
    '#FB8072',
    '#80B1D3',
    '#FDB462',
    '#B3DE69',
    '#FCCDE5',
    '#D9D9D9',
    '#BC80BD',
    '#CCEBC5',
    '#FFED6F',
    '#E41A1C',
    '#377EB8',
    '#4DAF4A',
    '#984EA3',
    '#FF7F00',
    '#FFFF33',
    '#A65628',
    '#F781BF',
    '#999999'
  )
cols <- cols[seq_along(unique(unsup$clust))]
names(cols) <- unique(unsup$clust)

# make the flightpath plot
fp <- flightpath_plot(flightpath_result = NULL, insitutype_result = unsup, col = cols[unsup$clust])
class(fp)
print(fp)



## ----fp_layout----------------------------------------------------------------
# compute the flightpath layout:
fp_layout <- flightpath_layout(logliks = unsup$logliks, profiles = unsup$profiles)
str(fp_layout)
# plot it:
#par(mar = c(0,0,0,0))
#plot(fp_layout$cellpos, pch = 16, cex = 0.5, col = cols[unsup$clust], xaxt = "n", yaxt = "n", xlab = "", ylab = "")
#text(fp_layout$clustpos, rownames(fp_layout$clustpos), cex = 0.5)

## ----refineClusters, fig.width = 5, fig.height = 5----------------------------
# refine the clusters:
newclusts <- refineClusters(logliks = unsup$logliks,
                            merges = c("g" = "newcluster", "e" = "newcluster", "c" = "c_renamed"), 
                            to_delete = "a",
                            subcluster = c("f" = 2),
                            counts = counts,
                            neg = negmean) 
str(newclusts)

# plot the updated results:
cols <-
  c(
    '#8DD3C7',
    '#BEBADA',
    '#FB8072',
    '#80B1D3',
    '#FDB462',
    '#B3DE69',
    '#FCCDE5',
    '#D9D9D9',
    '#BC80BD',
    '#CCEBC5',
    '#FFED6F',
    '#E41A1C',
    '#377EB8',
    '#4DAF4A',
    '#984EA3',
    '#FF7F00',
    '#FFFF33',
    '#A65628',
    '#F781BF',
    '#999999'
  )
cols <- cols[seq_along(unique(newclusts$clust))]
names(cols) <- unique(newclusts$clust)
fp <- flightpath_plot(flightpath_result = NULL, insitutype_result = newclusts, col = cols[newclusts$clust])
class(fp)
print(fp)



## ----colorCellTypes, fig.width = 8, fig.height = 5----------------------------


par(mfrow = c(1, 3))
par(mar = c(0, 0, 3, 0))

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "brewers palette",
     col = colorCellTypes(freqs = table(unsup$clust), palette = "brewers")[unsup$clust], 
     xlab = "", ylab = "", xaxt = "n", yaxt = "n")

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "tableau20 palette",
     col = colorCellTypes(freqs = table(unsup$clust), palette = "tableau20")[unsup$clust], 
     xlab = "", ylab = "", xaxt = "n", yaxt = "n")

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "earthplus palette",
     col = colorCellTypes(freqs = table(unsup$clust), palette = "earthplus")[unsup$clust], 
     xlab = "", ylab = "", xaxt = "n", yaxt = "n")


## ----sessioninfo--------------------------------------------------------------
sessionInfo()

