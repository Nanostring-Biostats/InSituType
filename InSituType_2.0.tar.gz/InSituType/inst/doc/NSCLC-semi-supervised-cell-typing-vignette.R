## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----installation, eval=FALSE-------------------------------------------------
#  
#  # TBD
#  

## ----setup--------------------------------------------------------------------
library(InSituType)
data("ioprofiles")
data("iocolors")
data("mini_nsclc")
str(mini_nsclc)
set.seed(0)

## ----strcounts----------------------------------------------------------------
counts <- mini_nsclc$counts
str(counts)
counts[25:30, 9:14]


## ----strnegmean---------------------------------------------------------------
negmean <- Matrix::rowMeans(mini_nsclc$neg)
head(negmean)

## ----refmat-------------------------------------------------------------------
data(ioprofiles)
str(ioprofiles)
ioprofiles[1:5, 1:10]

## ----anchors, fig.width=6, fig.height=5---------------------------------------
# compute the statistics used to define anchor cells.
# (This step is slow for big datasets. It's recommended to run this once and save the results. 
# Then you can iteratively adjust your choices when selecting anchor cells)
astats <- get_anchor_stats(counts = mini_nsclc$counts,
                           neg = Matrix::rowMeans(mini_nsclc$neg),
                           profiles = ioprofiles)

# estimate per-cell bg as a fraction of total counts:
negmean.per.totcount <- mean(rowMeans(mini_nsclc$neg)) / mean(rowSums(counts))
per.cell.bg <- rowSums(counts) * negmean.per.totcount

# now choose anchors:
anchors <- choose_anchors_from_stats(counts = counts, 
                                     neg = mini_nsclc$negmean, 
                                     bg = per.cell.bg,
                                     anchorstats = astats, 
                                     # a very low value chosen for the mini
                                     # dataset. Typically hundreds of cells
                                     # would be better.
                                     n_cells = 50, 
                                     min_cosine = 0.4, 
                                     min_scaled_llr = 0.03, 
                                     insufficient_anchors_thresh = 5)

# plot the anchors atop the UMAP:
par(mfrow = c(1, 1))
plot(mini_nsclc$umap, pch = 16, cex = 0.1, col = "peachpuff1", xaxt = "n",  yaxt = "n", xlab = "", ylab = "",
     main = "Selected anchor cells")
points(mini_nsclc$umap[!is.na(anchors), ], col = iocolors[anchors[!is.na(anchors)]], pch = 16, cex = 0.6)
legend("topright", pch = 16, col = iocolors[setdiff(unique(anchors), NA)], legend = setdiff(unique(anchors), NA), cex = 0.65)


## ----updateprofiles-----------------------------------------------------------
updatedprofiles <- updateReferenceProfiles(reference_profiles = ioprofiles, 
                                           counts = mini_nsclc$counts, 
                                           neg = mini_nsclc$neg, 
                                           bg = per.cell.bg,
                                           anchors = anchors) 
str(updatedprofiles)

## ----updateprofiles_fast, eval = FALSE----------------------------------------
#  updatedprofiles <- updateReferenceProfiles(reference_profiles = ioprofiles,
#                                             counts = mini_nsclc$counts,
#                                             neg = mini_nsclc$neg,
#                                             bg = per.cell.bg,
#                                             anchors = NULL)
#  

## ----cohorting, echo = TRUE---------------------------------------------------
# simulate immunofluorescence data: 
immunofluordata <- matrix(rpois(n = nrow(counts) * 4, lambda = 100), 
                          nrow(counts))
# perform automatic cohorting:
cohort <- fastCohorting(immunofluordata,
                        gaussian_transform = TRUE) 
# ("Gaussian_transform = TRUE" maps variables to gaussians in order to 
#  place dramatically different variables on the same scale.)
table(cohort)

## ----unsup, echo=TRUE---------------------------------------------------------
semisup <- insitutype(
  x = counts,
  neg = negmean,
  cohort = cohort,
  # Enter your own per-cell background estimates here if you
  # have them; otherwise insitutype will use the negprobes to
  # estimate background for you.
  bg = NULL,
  # condensed to save time. n_clusts = 5:15 would be more optimal
  n_clusts = c(5, 6),
  reference_profiles = updatedprofiles$updated_profiles,
  update_reference_profiles = FALSE,
  # choosing inadvisably low numbers to speed the vignette; using the defaults
  # in recommended.
  n_phase1 = 200,
  n_phase2 = 500,
  n_phase3 = 2000,
  n_starts = 1,
  max_iters = 5
) 

## ----unsup_results, fig.width = 8, fig.height = 6-----------------------------
str(semisup)
round(head(semisup$prob), 2)
heatmap(sweep(semisup$profiles, 1, pmax(apply(semisup$profiles, 1, max), .2), "/"), scale = "none",
        main = "Mean cell type expression profiles")

# define cluster colors:
cols <-
  c(
    '#8DD3C7',
    '#BEBADA',
    '#FB8072',
    '#80B1D3',
    '#FDB462',
    '#B3DE69',
    '#FCCDE5',
    '#D9D9D9',
    '#BC80BD',
    '#CCEBC5',
    '#FFED6F',
    '#E41A1C',
    '#377EB8',
    '#4DAF4A',
    '#984EA3',
    '#FF7F00',
    '#FFFF33',
    '#A65628',
    '#F781BF',
    '#999999'
  )
cols <- cols[seq_along(unique(semisup$clust))]
names(cols) <- unique(semisup$clust)
cols[is.element(names(cols), names(iocolors))] <- iocolors[names(cols)[is.element(names(cols), names(iocolors))]]

par(mfrow = c(1, 2))
par(mar = c(0, 0, 3, 0))

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "cells in physical space",
     col = cols[semisup$clust], xlab = "", ylab = "", xaxt = "n", yaxt = "n")

plot(mini_nsclc$umap, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
     main = "cells in UMAP space",     
     col = cols[semisup$clust], xlab = "", ylab = "", xaxt = "n", yaxt = "n")
legend("bottomleft", pch = 16, col = cols, legend = names(cols), cex = 0.7)



## ----flightpath, fig.width = 5, fig.height = 5--------------------------------

# make the flightpath plot
fp <- flightpath_plot(flightpath_result = NULL, insitutype_result = semisup, col = cols[semisup$clust])
class(fp)
print(fp)



## ----fp_layout----------------------------------------------------------------
# compute the flightpath layout:
fp_layout <- flightpath_layout(logliks = semisup$logliks, profiles = semisup$profiles)
str(fp_layout)
# plot it:
#par(mar = c(0,0,0,0))
#plot(fp_layout$cellpos, pch = 16, cex = 0.5, col = cols[semisup$clust], xaxt = "n", yaxt = "n", xlab = "", ylab = "")
#text(fp_layout$clustpos, rownames(fp_layout$clustpos), cex = 0.5)

## ----refineClusters, fig.width = 5, fig.height = 5----------------------------
# refine the clusters:
newclusts <- refineClusters(
  logliks = semisup$logliks,
  merges = c("fibroblast" = "stroma", "endothelial" = "stroma"),
  to_delete = c("a"),
  # subclustering via refineClusters is not recommended for semi-supervised
  # results
  subcluster = NULL,
  counts = counts,
  neg = negmean
) 
str(newclusts)

# plot the updated results:
cols["stroma"] <- "black"
fp <- flightpath_plot(flightpath_result = NULL, insitutype_result = newclusts, col = cols[newclusts$clust])
class(fp)
print(fp)



## ----colorCellTypes, fig.width = 8, fig.height = 5----------------------------


par(mfrow = c(1, 3))
par(mar = c(0, 0, 3, 0))

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "brewers palette",
     col = colorCellTypes(freqs = table(semisup$clust), palette = "brewers")[semisup$clust], 
     xlab = "", ylab = "", xaxt = "n", yaxt = "n")

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "tableau20 palette",
     col = colorCellTypes(freqs = table(semisup$clust), palette = "tableau20")[semisup$clust], 
     xlab = "", ylab = "", xaxt = "n", yaxt = "n")

plot(mini_nsclc$x, mini_nsclc$y, pch = 16, cex = .75, asp = 1, cex.main = 0.75,
          main = "earthplus palette",
     col = colorCellTypes(freqs = table(semisup$clust), palette = "earthplus")[semisup$clust], 
     xlab = "", ylab = "", xaxt = "n", yaxt = "n")


## ----sessioninfo--------------------------------------------------------------
sessionInfo()

